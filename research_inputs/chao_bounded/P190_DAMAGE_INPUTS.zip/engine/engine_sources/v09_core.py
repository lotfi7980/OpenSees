"""SS-only HingeRadau builder and independent committed-state screening."""
from pathlib import Path
import csv,hashlib,json
import numpy as np

def append(path,rows):
    if not rows:return
    exists=path.exists()
    with path.open('a',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        if not exists:w.writeheader()
        w.writerows(rows)

def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()

def elastic_interior(ops,tag,E,points,Av,shear_material=None):
    A=sum(a for y,a in points);centroid=sum(y*a for y,a in points)/A
    I=sum(a*(y-centroid)**2 for y,a in points)
    ops.section('Elastic',tag,float(E),float(A),float(I))
    if shear_material is None:
        shear_material=tag+2;ops.uniaxialMaterial('Elastic',shear_material,float(E/2.6*Av))
    ops.section('Aggregator',tag+1,int(shear_material),'Vy','-section',tag)
    return tag+1,A,I

def build_ss(ns,original,mode,lp,ele_tag,node_i,node_j,section_name,rel_code):
    ops=ns['ops'];ops.v09_inside_ss=True
    try:
        if mode=='Lobatto6':return original(ele_tag,node_i,node_j,section_name,rel_code)
        if rel_code!=0:raise RuntimeError('SS_RELEASE_NOT_SUPPORTED')
        ns['check_new_element_tag'](ele_tag,'V09 SS HINGE RADAU')
        length=ns['get_frame_length'](node_i,node_j)
        if not 0<8*lp<length:raise ValueError('HingeRadau requires positive non-overlapping hinge regions')
        sec,meta=ns['_hybrid_ss_section'](ele_tag,section_name)
        points=ns['_fiber_section_points'](section_name);Av=ns['get_section_properties'](section_name)[1]
        middle=80_000_000+int(ele_tag)*10+2
        elastic,A,I=elastic_interior(ops,middle,ns['E0'],points,Av,70_000_000+int(ele_tag)*100+90)
        integration=90_000_000+int(ele_tag)*10
        ops.beamIntegration('HingeRadau',integration,sec,float(lp),sec,float(lp),elastic)
        local=ns.get('_p2_local',{})
        opts=['-iter',local.get('local_iterations',30),local.get('local_tolerance',1e-12)]
        if 'subdivisions' in local:opts+=['-subdivide',local['subdivisions'],local.get('subdivide_factor',10.)]
        ops.element('forceBeamColumn',int(ele_tag),int(node_i),int(node_j),ns['P_delta'],integration,*opts)
        meta.update(node_i=int(node_i),node_j=int(node_j),main_element_tag=int(ele_tag),topology='HINGE_RADAU_FIBER',integration_points=6,material_case=ns['SS_MATERIAL_CASE'],lp_mm=lp,elastic_A=A,elastic_I=I,elastic_section_tag=elastic,elastic_ips=[2,3,4,5])
        ns['ss_fiber_records'].append(meta)
        return dict(main_element_tag=int(ele_tag),internal_i=None,internal_j=None,spring_tags=[],release_i=False,release_j=False,I_middle=None,length=length,fiber=True)
    finally:ops.v09_inside_ss=False

class ScreeningStop(RuntimeError):pass

class Monitor:
    def __init__(self,out,controls,settings):
        self.out=Path(out);self.c=controls;self.settings=settings;self.seen=set();self.section_peaks={};self.global_peak=0.;self.initialized=False;self.last=None;self.loads={};self.event_keys=set();self.old={};self.work=0.
    def event(self,step,roof,kind,tag='',ip='',fiber='',value=''):
        key=(kind,tag,ip,fiber)
        if key in self.event_keys:return
        self.event_keys.add(key)
        append(self.out/'Events.csv',[dict(step=step,roof_mm=roof,event=kind,tag=tag,ip=ip,fiber=fiber,value=value)])
    def initialize(self,ns):
        ops=ns['ops'];context=ns['_automation'];c=self.c
        # Original recorder keeps a mutable list also appended by the lateral
        # pattern. Select actual gravity commands by their pattern, not alias.
        loads=[row[1:] for row in ops.v09_load_records if row[0]!=30];gravity=np.zeros(2)
        for name,args,kwargs in loads:
            if name=='load':gravity+=np.array(args[1:3],float)
            elif name=='eleLoad':
                if args[:1]!=['-ele'] or args[2:4]!=['-type','-beamUniform']:raise ScreeningStop('UNSUPPORTED_GRAVITY_LOAD_AUDIT')
                tag=int(args[1]);i,j=ops.eleNodes(tag);delta=np.array(ops.nodeCoord(j))-ops.nodeCoord(i);L=float(np.linalg.norm(delta));axis=delta/L
                wy=float(args[4]);wx=float(args[5]) if len(args)>5 else 0.
                gravity+=L*np.array([wx*axis[0]-wy*axis[1],wx*axis[1]+wy*axis[0]])
                self.loads[tag]=self.loads.get(tag,np.zeros(2))+np.array([wy,wx])
        self.gravity=gravity
        metadata=dict(gravity_D_factor=context.D_factor,gravity_L_factor=context.L_factor,T1_postgravity_s=ns['T1_gravity'],T1_initial_s=ns['T1_initial'],Ki_N_per_mm=context.Ki,
            outside_ss_commands_sha256=digest(ops.v09_outside_commands),gravity_commands_sha256=digest(loads),nodes=ops.getNodeTags(),elements=ops.getEleTags(),ss_tags=[r['etabs_tag'] for r in ns['ss_fiber_records']],outside_hinge_count=len(ns['hinge_records']),
            total_mass=[sum(ops.nodeMass(n,d) for n in ops.getNodeTags()) for d in [1,2,3]],gravity_external_N=gravity.tolist(),ss_sections=ns['ss_fiber_records'],lp_status='UNCERTAIN_NUMERICAL_SCENARIO',physical_validation=False)
        (self.out/'Model_Audit.json').write_text(json.dumps(metadata,indent=2))
        lateral=[row[1:] for row in ops.v09_load_records if row[0]==30]
        metadata['lateral_commands_sha256']=digest(lateral)
        (self.out/'Model_Audit.json').write_text(json.dumps(metadata,indent=2))
        (self.out/'Lateral_Commands.json').write_text(json.dumps(lateral,indent=2))
        (self.out/'Outside_SS_Commands.json').write_text(json.dumps(ops.v09_outside_commands))
        (self.out/'Gravity_Commands.json').write_text(json.dumps(loads))
        if not self.settings['scenario'].get('bootstrap',False) and abs(metadata['T1_postgravity_s']/c['reference_T1_s']-1)>c['period_relative_tolerance']:raise ScreeningStop('MODAL_REGRESSION_REJECTED')
        self.initialized=True
    def capture(self,ns,step,roof,shear,additional_reasons=None):
        if not self.initialized:self.initialize(ns)
        ops=ns['ops'];context=ns['_automation'];c=self.c
        loadfactor=float(ops.getLoadFactor(30));sections=[];members=[];fibers=[];reasons=list(additional_reasons or []);maxeps=0.;maxcurv=0.;incremental_work=0.
        for rec in ns['ss_fiber_records']:
            tag=int(rec['etabs_tag']);i,j=ops.eleNodes(tag);L=float(np.linalg.norm(np.asarray(ops.nodeCoord(j))-ops.nodeCoord(i)))
            x=ops.eleResponse(tag,'integrationPoints');weights=ops.eleResponse(tag,'integrationWeights')
            q=np.array(ops.eleResponse(tag,'basicForce'),float);v=np.array(ops.eleResponse(tag,'basicDeformation'),float);integrated=np.zeros(3)
            wy,wx=self.loads.get(tag,[0.,0.]);eqratio=0.;fiber_ratio=0.;kinratio=0.;member_reasons=[]
            for ip,(xx,w) in enumerate(zip(x,weights),1):
                xi=xx/L;B=np.array([[1.,0.,0.],[0.,xi-1.,xi],[0.,1./L,1./L]])
                sf=np.asarray(ops.eleResponse(tag,'section',ip,'force'),float);sd=np.asarray(ops.eleResponse(tag,'section',ip,'deformation'),float)
                if sf.size!=3 or sd.size!=3 or not np.isfinite(np.r_[sf,sd]).all():raise ScreeningStop('MISSING_OR_NONFINITE_SECTION_RESPONSE')
                expected=B@q+np.array([wx*(L-xx),wy*.5*xx*(xx-L),wy*(xx-.5*L)])
                tolerance=np.array([c['force_atol_N'],c['moment_atol_Nmm'],c['force_atol_N']])+c['force_rtol']*np.maximum(abs(expected),abs(sf))
                er=float(max(abs(sf-expected)/tolerance));eqratio=max(eqratio,er);integrated+=w*(B.T@sd)
                data=np.asarray(ops.eleResponse(tag,'section',ip,'fiberData'),float);is_elastic=ip in rec.get('elastic_ips',[])
                f=None;epsmax=0.;fr=0.;kr=0.
                if not is_elastic:
                    if data.size==0 or data.size%5:raise ScreeningStop('MISSING_FIBER_RESPONSE')
                    f=data.reshape(-1,5);y,z,a,stress,strain=f.T
                    if not np.isfinite(f).all() or min(a)<=0:raise ScreeningStop('INVALID_FIBER_DATA')
                    centroid=sum(a*y)/sum(a);predicted=sd[0]-(y-centroid)*sd[1]
                    kr=float(max(abs(strain-predicted)/(c['fiber_strain_atol']+c['fiber_strain_rtol']*abs(strain))));kinratio=max(kinratio,kr)
                    calc=np.array([sum(a*stress),-sum(a*stress*(y-centroid))]);fr=float(max(abs(calc-sf[:2])/tolerance[:2]));fiber_ratio=max(fiber_ratio,fr)
                    epsmax=float(max(abs(strain)));maxeps=max(maxeps,epsmax)
                    if epsmax>c['envelope_strain_limit']:member_reasons.append(f'IP{ip}:OUTSIDE_ENVELOPE')
                    bound=c['envelope_strain_limit']/max(abs(y-centroid))
                    if abs(sd[1])>bound*(1+c['fiber_strain_rtol']):member_reasons.append(f'IP{ip}:CURVATURE_OUTSIDE_ENVELOPE')
                    for fi,(fy,fz,fa,fs,fe) in enumerate(f):
                        if abs(fe)>=396.75/200000.:self.event(step,roof,'FIBER_YIELD_CROSSING',tag,ip,fi,float(fe))
                        if abs(fe)>=self.settings.get('cap_strain',float('inf')):self.event(step,roof,'FIBER_CAP_CROSSING',tag,ip,fi,float(fe))
                        if tag in c['record_fiber_tags']:fibers.append(dict(step=step,roof_mm=roof,tag=tag,ip=ip,x_mm=xx,weight_mm=w,fiber=fi,y_mm=fy,z_mm=fz,area_mm2=fa,stress_MPa=fs,strain=fe))
                else:
                    calc=np.array([ns['E0']*rec['elastic_A']*sd[0],ns['E0']*rec['elastic_I']*sd[1]])
                    fr=float(max(abs(calc-sf[:2])/tolerance[:2]));fiber_ratio=max(fiber_ratio,fr)
                key=(tag,ip);old=self.old.get(key)
                if old is not None:
                    oldf,oldd,olds=old
                    if f is not None:incremental_work+=w*float(sum(f[:,2]*.5*(f[:,3]+oldf[:,3])*(f[:,4]-oldf[:,4])))+w*.5*(sf[2]+olds[2])*(sd[2]-oldd[2])
                    else:incremental_work+=w*float(np.dot(.5*(sf+olds),sd-oldd))
                self.old[key]=(None if f is None else f.copy(),sd.copy(),sf.copy())
                peak=self.section_peaks.get(key,abs(sf[1]));peak=max(peak,abs(sf[1]));self.section_peaks[key]=peak
                if peak>1e6 and abs(sf[1])<.95*peak:self.event(step,roof,'SECTION_MOMENT_DECLINE_5PCT',tag,ip,value=float(sf[1]))
                maxcurv=max(maxcurv,abs(float(sd[1])))
                sections.append(dict(step=step,roof_mm=roof,tag=tag,ip=ip,type='ELASTIC_INTERIOR' if is_elastic else 'FIBER',x_mm=xx,weight_mm=w,P_N=sf[0],M_Nmm=sf[1],V_N=sf[2],axial_strain=sd[0],curvature_per_mm=sd[1],shear_strain=sd[2],max_abs_fiber_strain=epsmax,section_force_ratio=er,fiber_force_ratio=fr,fiber_kinematics_ratio=kr))
            cv=float(max(abs(integrated-v)/(np.array([c['member_axial_atol_mm'],c['member_rotation_atol_rad'],c['member_rotation_atol_rad']])+c['member_rtol']*np.maximum(abs(integrated),abs(v)))))
            for label,ratio in [('COMPATIBILITY',cv),('SECTION_FORCE',eqratio),('FIBER_FORCE',fiber_ratio),('FIBER_KINEMATICS',kinratio)]:
                if not np.isfinite(ratio) or ratio>1:member_reasons.append(label)
            reasons.extend(f'T{tag}:{r}' for r in dict.fromkeys(member_reasons))
            members.append(dict(step=step,roof_mm=roof,tag=tag,P_basic_N=q[0],M_i_Nmm=-q[1],M_j_Nmm=q[2],basic_axial_mm=v[0],basic_rotation_i=v[1],basic_rotation_j=v[2],integrated_axial_mm=integrated[0],integrated_rotation_i=integrated[1],integrated_rotation_j=integrated[2],compatibility_ratio=cv,section_force_ratio=eqratio,fiber_force_ratio=fiber_ratio,fiber_kinematics_ratio=kinratio,reasons=';'.join(member_reasons)))
        ops.reactions();reaction=np.array([sum(ops.nodeReaction(n,d) for n in ops.getNodeTags()) for d in [1,2]])
        external=self.gravity+np.array([sum(context.nodal_loads.values())*context.direction*loadfactor,0.])
        residual=reaction+external
        globalratio=float(max(abs(residual)/(c['global_force_atol_N']+c['global_force_rtol']*np.maximum(abs(reaction),abs(external)))))
        if not np.isfinite(globalratio) or globalratio>1:reasons.append('GLOBAL_TRANSLATIONAL_EQUILIBRIUM')
        self.work+=incremental_work;self.global_peak=max(self.global_peak,shear)
        if self.global_peak>0 and shear<.95*self.global_peak:self.event(step,roof,'GLOBAL_BASE_SHEAR_DECLINE_5PCT',value=shear)
        state=dict(step=step,roof_mm=roof,base_shear_kN=shear,load_factor=loadfactor,numerically_converged=True,mechanical_screen_passed=not reasons,envelope_passed=maxeps<=c['envelope_strain_limit'],max_abs_fiber_strain=maxeps,max_abs_curvature_per_mm=maxcurv,global_residual_x_N=residual[0],global_residual_y_N=residual[1],global_equilibrium_ratio=globalratio,internal_work_since_gravity_Nmm=self.work,algorithm=ops.v09_algorithm,integrator=ops.v09_integrator,physical_validation=False,reasons=';'.join(reasons))
        stories=[];previous_elevation=0.;previous_ux=0.
        for index,level in enumerate(context.levels,1):
            ux=float(np.mean([ops.nodeDisp(n,1) for n in level['mass_nodes']]))
            stories.append(dict(step=step,roof_mm=roof,story=index,elevation_mm=level['elevation'],ux_mm=ux,drift_ratio=(ux-previous_ux)/(level['elevation']-previous_elevation)))
            previous_elevation=level['elevation'];previous_ux=ux
        for name,rows in [('Capacity_All.csv',[state]),('SS_Sections.csv',sections),('SS_Members.csv',members),('Fiber_86_116.csv',fibers),('Story_Drifts.csv',stories)]:append(self.out/name,rows)
        (self.out/'Last_Numerically_Converged.json').write_text(json.dumps(state,indent=2))
        append(self.out/'State_Assessment.csv',[dict(step=step,roof_mm=roof,numerically_converged=True,independent_mechanical_checks_passed=not any(r not in list(additional_reasons or []) for r in reasons),continuation_direction_passed=not bool(additional_reasons),envelope_passed=state['envelope_passed'],accepted=not reasons,physical_validation=False)])
        self.last=state
        if reasons:
            (self.out/'Rejected_State.json').write_text(json.dumps(state,indent=2));raise ScreeningStop('MECHANICAL_SCREEN_REJECTED: '+state['reasons'])
        append(self.out/'Capacity_Accepted.csv',[state]);(self.out/'Last_Screened_State.json').write_text(json.dumps(state,indent=2))
