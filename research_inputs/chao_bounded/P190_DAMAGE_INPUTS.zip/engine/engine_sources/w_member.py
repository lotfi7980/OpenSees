"""General 2D strong-axis W fiber research model. Units: N, mm, MPa.

No empirical buckling/fracture relation is inferred from section dimensions.
Geometry, material, shear area, integration length and evidence are explicit.
Tags are caller-owned. Beam loads, masses, releases and transformations remain
the caller's responsibility; unsupported releases are rejected.
"""
from dataclasses import dataclass,asdict
import json,warnings
from pathlib import Path
import numpy as np

@dataclass(frozen=True)
class WSection:
    name:str
    d:float
    bf:float
    tf:float
    tw:float
    root_radius:float|None
    A_reference:float|None
    I_reference:float|None
    Av:float
    geometry_source:str
    k:float|None=None

    def fibers(self,order=16):
        if order<4 or order%2:raise ValueError('Use even quadrature order >= 4')
        if min(self.d,self.bf,self.tf,self.tw,self.Av)<=0 or self.d<=2*self.tf or self.bf<=self.tw:raise ValueError('Invalid W geometry')
        r=self.root_radius if self.root_radius is not None else (self.k-self.tf if self.k is not None else None)
        if self.k is not None and self.root_radius is not None and abs(self.k-self.tf-self.root_radius)>1e-6:raise ValueError('k and root radius describe inconsistent geometry; identify k convention')
        if r is None:
            warnings.warn('Root radius missing: explicit sharp-corner approximation; not validated')
            r=0.
        if r<0 or 2*r>self.d-2*self.tf or 2*r>self.bf-self.tw:raise ValueError('Invalid root radius')
        q,w=np.polynomial.legendre.leggauss(order);pts=[]
        def strip(lo,hi,width):
            for x,wt in zip(q,w):
                y=(lo+hi)/2+x*(hi-lo)/2
                pts.append((float(y),float(width(y)*wt*(hi-lo)/2)))
        h=self.d/2-self.tf
        full_q,full_w=q,w
        q,w=np.polynomial.legendre.leggauss(order//2)
        strip(h,self.d/2,lambda y:self.bf)
        strip(-self.d/2,-h,lambda y:self.bf)
        q,w=full_q,full_w
        strip(-h,h,lambda y:self.tw)
        if r:
            q,w=np.polynomial.legendre.leggauss(order)
            for sign in [1,-1]:
                # Two root fillets per flange, symmetric about the web.
                for x,wt in zip(q,w):
                    angle=(x+1)*np.pi/4
                    y=h-r*(1-np.sin(angle))
                    width=2*r*(1-np.cos(angle))
                    pts.append((float(sign*y),float(width*r*np.cos(angle)*wt*np.pi/4)))
        return np.array(pts)

    def audit(self,order=16,tolerance=.005):
        f=self.fibers(order);y,a=f.T;A=float(sum(a));I=float(sum(a*y*y))
        errors={k:None if ref is None else val/ref-1 for k,val,ref in [('A',A,self.A_reference),('I',I,self.I_reference)]}
        passed=all(v is not None and abs(v)<=tolerance for v in errors.values())
        return dict(section=asdict(self),fiber_count=len(f),A_mm2=A,I_mm4=I,centroid_mm=float(sum(y*a)/A),relative_errors=errors,geometry_gate=passed,physical_validation=False)

@dataclass(frozen=True)
class Material:
    E:float
    Fy:float
    Fu:float|None
    nu:float
    hardening:float
    source:str

@dataclass(frozen=True)
class MemberContext:
    length:float
    boundary:str
    releases:tuple
    axial_N:float|None
    unbraced_length:float|None
    bracing:str|None
    history:str
    connection:dict|None

def evidence_gate(section,material,context,mechanism,evidence):
    missing=[]
    for k in ['Fu']:
        if getattr(material,k) is None:missing.append(k)
    for k in ['axial_N','unbraced_length','bracing','connection']:
        if getattr(context,k) is None:missing.append(k)
    if section.root_radius is None and section.k is None:missing.append('root_radius_or_k')
    if not section.audit()['geometry_gate']:missing.append('verified_A_I')
    for k in ['calibration_specimens','held_out_specimens','applicability_domain','independent_validation_passed']:
        if not evidence.get(k):missing.append(k)
    valid=not missing
    if not valid:warnings.warn('Research model only; missing evidence: '+', '.join(missing))
    return dict(mechanism=mechanism,missing=missing,declared_evidence_complete=valid,physical_validation=False,evidence=evidence,
                status='EXTERNAL_EVIDENCE_REQUIRES_REVIEW' if valid else 'RESEARCH_ONLY')

def regularized_envelope(E,points,h,reference_h,G_excess,residual,domain,mode):
    """Scale plastic opening, not elastic strain. G is excess above residual.

    points includes yield through cap in (stress,strain) order. No inferred
    buckling or rupture strain. Residual plateau work is NOT fracture energy.
    """
    if min(E,h,reference_h,G_excess)<=0 or mode not in ['fixed_material','plastic_opening']:raise ValueError('Invalid regularization inputs')
    env=[(float(s),float(e)) for s,e in points]
    if mode=='plastic_opening':env=[(s,s/E+reference_h/h*(e-s/E)) for s,e in env]
    sc,ec=env[-1]
    if not 0<=residual<sc:raise ValueError('Residual must lie below cap stress')
    er=ec+2*G_excess/(h*(sc-residual))+(residual-sc)/E
    if er<=ec or er>domain or any(env[i+1][1]<=env[i][1] for i in range(len(env)-1)):raise ValueError('Envelope outside explicit domain or nonmonotone strain')
    actual=.5*(sc-residual)*h*((er-residual/E)-(ec-sc/E))
    return env+[(residual,er),(residual,domain)],dict(G_excess_N_per_mm=actual,h_mm=h,reference_h_mm=reference_h,mode=mode,domain=domain,physical_validation=False)

def build_member(ops,tag,node_i,node_j,transformation,section,material,context,order,integration,lp,law,evidence):
    """Create a forceBeamColumn with elastic Vy aggregation.

    law: kind Steel02, or HystereticSM with explicit pos/neg envelopes.
    Architecture B connections must be constructed separately and audited;
    they are never silently inserted into this member.
    """
    if any(context.releases):raise ValueError('Releases require an explicitly audited topology')
    L=float(np.linalg.norm(np.array(ops.nodeCoord(node_j))-ops.nodeCoord(node_i)))
    if abs(L-context.length)>1e-6*L:raise ValueError('Context length differs from node geometry')
    audit=section.audit(order)
    if not audit['geometry_gate']:raise ValueError('A/I geometry gate failed or reference absent')
    if min(material.E,material.Fy)<=0 or not -1<material.nu<.5 or material.hardening<0:raise ValueError('Invalid material inputs')
    if integration=='HingeRadau' and (lp is None or not 0<8*lp<L):raise ValueError('Explicit uncertain lp required, with 8lp < L')
    if integration=='Lobatto' and law['kind']!='Steel02':raise ValueError('Softening Lobatto requires an IP-specific length audit; not implemented')
    if integration not in ['HingeRadau','Lobatto']:raise ValueError('Unsupported integration')
    if law['kind'] not in ['Steel02','HystereticSM']:raise ValueError('Unsupported law; no implicit degradation defaults')
    mat=tag*100+1;shear=tag*100+2;fiber=tag*100+3;agg=tag*100+4;elastic=tag*100+5;elasticagg=tag*100+6;bi=tag*100+7
    if law['kind']=='Steel02':ops.uniaxialMaterial('Steel02',mat,material.Fy,material.E,material.hardening,*law['transition'])
    elif law['kind']=='HystereticSM':
        ops.uniaxialMaterial('HystereticSM',mat,'-posEnv',*[v for p in law['positive'] for v in p],'-negEnv',*[v for p in law['negative'] for v in p])
    else:raise ValueError('Unsupported law; no implicit degradation defaults')
    ops.uniaxialMaterial('Elastic',shear,material.E/(2*(1+material.nu))*section.Av)
    ops.section('Fiber',fiber)
    for y,a in section.fibers(order):ops.fiber(float(y),0.,float(a),mat)
    ops.section('Aggregator',agg,shear,'Vy','-section',fiber)
    ops.section('Elastic',elastic,material.E,audit['A_mm2'],audit['I_mm4'])
    ops.section('Aggregator',elasticagg,shear,'Vy','-section',elastic)
    if integration=='HingeRadau':
        if lp is None or not 0<8*lp<L:raise ValueError('Explicit uncertain lp required, with 8lp < L')
        ops.beamIntegration('HingeRadau',bi,agg,lp,agg,lp,elasticagg)
    elif integration=='Lobatto':
        if law['kind']!='Steel02':raise ValueError('Softening Lobatto requires an IP-specific length audit; not implemented')
        ops.beamIntegration('Lobatto',bi,agg,law['integration_points'])
    else:raise ValueError('Unsupported integration')
    ops.element('forceBeamColumn',tag,node_i,node_j,transformation,bi,'-iter',50,1e-12)
    audit.update(material=asdict(material),context=asdict(context),law=law,integration=integration,lp_uncertain_mm=lp,evidence=evidence,physical_validation=False)
    return audit

def plastic_interaction(section,Fy,order=32,samples=201):
    """Ideal plastic strong-axis P-M envelope; not a buckling interaction law."""
    y,a=section.fibers(order).T;out=[]
    for c in np.linspace(-section.d,section.d,samples):
        stress=Fy*np.sign(y-c);out.append((float(sum(stress*a)),float(sum(stress*a*y))))
    return np.array(out)

def write_audit(path,audit):
    import csv
    path=Path(path);path.write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    rows=[]
    def flatten(value,key):
        if isinstance(value,dict):
            for k,v in value.items():flatten(v,key+'.'+str(k) if key else str(k))
        elif isinstance(value,(list,tuple)):
            for i,v in enumerate(value):flatten(v,f'{key}[{i}]')
        else:rows.append(dict(parameter=key,value=value))
    flatten(audit,'')
    with path.with_suffix('.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['parameter','value']);w.writeheader();w.writerows(rows)

def select_deterioration(config):
    """Fail-closed selection: absent evidence never creates a hidden backbone."""
    architecture=config['architecture']
    if architecture=='A':
        if config.get('model')=='Kolwankar2018_NFE':
            raise NotImplementedError('The published nonlocal element is not implemented by local HystereticSM. Use literature_models only as a relation evaluator.')
        if config.get('model')!='effective_research':raise ValueError('Unknown material deterioration model')
        required=['positive_envelope','negative_envelope','length_mode','reference_length','G_excess','source','domain']
    elif architecture=='B':
        required=['mechanism','K_Nmm_per_rad','Mc_Nmm','Mr_Nmm','inelastic_opening_rad','source','connection_details']
    else:raise ValueError('Architecture must be A or B')
    missing=[k for k in required if k not in config or config[k] is None]
    if missing:raise ValueError('Deterioration inputs missing: '+', '.join(missing))
    return dict(inputs=config,physical_validation=False,status='EXPLICIT_RESEARCH_PARAMETERS_ONLY')

def build_effective_rotational_failure(ops,tag,node_i,node_j,mat_tag,config):
    """Architecture B research M-opening component, no pre-cap plastic hinge.

    Translation constraints are deliberately owned by the frame assembler,
    which must resolve its existing diaphragm retained nodes to avoid chains.
    Finite K adds real series compliance; no beam E/I correction is applied.
    """
    result=select_deterioration(dict(config,architecture='B'))
    if np.linalg.norm(np.asarray(ops.nodeCoord(node_i))-ops.nodeCoord(node_j))>1e-8:raise ValueError('Failure spring nodes must coincide')
    K=config['K_Nmm_per_rad'];Mc=config['Mc_Nmm'];Mr=config['Mr_Nmm'];opening=config['inelastic_opening_rad']
    if K<=0 or Mc<=0 or not 0<=Mr<Mc or opening<=0:raise ValueError('Invalid M-opening backbone')
    theta=Mc/K
    env=[.5*Mc,.5*theta,Mc,theta,Mr,theta+opening]
    ops.uniaxialMaterial('Hysteretic',mat_tag,*env,*[-v for v in env],1.,1.,0.,0.)
    ops.element('zeroLength',tag,node_i,node_j,'-mat',mat_tag,'-dir',3)
    return dict(**result,elastic_until_threshold=True,series_compliance_rad_per_Nmm=1/K,plasticity_in_beam_preserved=True,
                constraint_requirement='Caller must couple translations to final retained nodes; check force, kinematics and work.')
