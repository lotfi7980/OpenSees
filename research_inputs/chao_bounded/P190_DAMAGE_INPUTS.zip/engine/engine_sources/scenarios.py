"""Parameter-driven inverse research experiments, never physical validation."""
from pathlib import Path
import json
import numpy as np
from v09_core import build_ss,Monitor,append,ScreeningStop
ROOT=Path(__file__).resolve().parent
PARAMS={}

def configure(name,c,settings):
    p=json.loads((ROOT/'parameters'/f'{name}.json').read_text());PARAMS[name]=p
    settings.update(scenario=p,architecture=p['architecture'],physical_calibration=False,
        cap_strain=p.get('cap',1e10),solver_reference_strain=p.get('solver_reference',p.get('cap',.1)),
        analysis_displacement_tolerance=p.get('tolerance',1e-9))
    c['envelope_strain_limit']=p.get('domain',.8)
    if 'Mc' not in p and not p.get('control_law'):c['envelope_strain_limit']=p.get('domain',.8) if p.get('residual_hold',False) else envelope(p,settings['lp'])[1]
    if p.get('gravity_mode')=='BASELINE_NSP':
        if p.get('bootstrap',False):c['period_relative_tolerance']=.01
        else:c['reference_T1_s']=json.loads((ROOT/'Matched_Gravity_Reference.json').read_text())['T1_postgravity_s']
    c['maximum_steps']=p.get('maxsteps',1600)
    c['dc_near_cap_step_mm']=p.get('near_step',.5)
    c['arc_initial_roof_scale_mm']=p.get('arc_scale',.15)
    c['record_fiber_tags']=[86,116] if p.get('detailed',False) else []
    if p.get('postpeak_80pct'):c['record_fiber_tags']=[214]
    c['interpretation']='Explicit effective-law numerical calibration range; not coupon or fracture strain.'
    if 'Mc' in p:c['period_relative_tolerance']=.001

def envelope(p,lp):
    fy=396.75;E=200000.;sc=fy*p['peak_ratio'];sr=fy*p['residual_ratio']
    cap=p['cap'];kink=.015;h=lp
    if p.get('length_mode')=='plastic_opening_regularized':
        scale=p.get('reference_lp',100.)/h
        cap=sc/E+scale*(cap-sc/E);kink=444.36/E+scale*(kink-444.36/E)
    end=cap+2*p['G_N_per_mm']/(h*(sc-sr))+(sr-sc)/E
    if end<=cap or end>p.get('domain',.8):raise ValueError('Energy envelope exceeds declared coverage')
    # Energy regularization scales the plastic post-cap branch only.
    env=[(fy,fy/E),(444.36,kink),(sc,cap),(sr,end)]
    if p.get('residual_hold',False):env.append((sr,p.get('domain',.8)))
    return env,end

def material(ops,tag,p,lp):
    if p.get('control_law')=='STEEL02':ops.uniaxialMaterial('Steel02',tag,396.75,200000.,.01,18.,.925,.15);return
    if p.get('control_law'):
        fy=396.75;ey=fy/200000.
        env={'CONTROL':[(fy,ey),(fy+2000*ey,2*ey)],'LATE_NO_DROP':[(fy,ey),(444.36,.015)],'LATE':[(fy,ey),(444.36,.015),(257.8875,.030),(59.5125,.045)]}[p['control_law']]
        ops.uniaxialMaterial('HystereticSM',tag,'-posEnv',*[v for pair in env for v in pair],'-negEnv',*[-v for pair in env for v in pair]);return
    if 'Mc' in p:
        ops.uniaxialMaterial('Steel02',tag,396.75,200000.,.01,18.,.925,.15);return
    env,end=envelope(p,lp)
    if p.get('material_api')=='Hysteretic':
        neg=[env[0],env[2],env[3]];pos=neg
        if p.get('compression_only',False):
            fy=396.75;ey=fy/200000.;pos=[(fy,ey),(fy+2000*(p['cap']-ey),p['cap']),(fy+2000*(p['domain']-ey),p['domain'])]
        ops.uniaxialMaterial('Hysteretic',tag,*[v for pair in pos for v in pair],*[-v for pair in neg for v in pair],1.,1.,0.,0.)
        return
    ops.uniaxialMaterial('HystereticSM',tag,'-posEnv',*[v for pair in env for v in pair],'-negEnv',*[-v for pair in env for v in pair])

def install(ns,original,mode,lp,name,ele,i,j,section,release):
    p=PARAMS[name];ns['_p2_local']=p;ops=ns['ops'];old=ns['_hybrid_ss_section']
    if p.get('generic_sections_config'):
        from w_member import WSection
        specs={k:WSection(**v) for k,v in json.loads((ROOT.parent/p['generic_sections_config']).read_text()).items()}
        old_points=ns['_fiber_section_points']
        def section_points(name,mesh_order=None):
            if name in specs:
                audit=specs[name].audit(mesh_order or ns['FIBER_MESH_ORDER'])
                if not audit['geometry_gate']:raise ValueError('Five-story SS A/I failed')
                ns.setdefault('_v11_geometry_audits',{})[name]=audit
                return specs[name].fibers(mesh_order or ns['FIBER_MESH_ORDER']).tolist()
            return old_points(name,mesh_order)
        ns['_fiber_section_points']=section_points

    if p.get('generic_section_config'):
        import sys
        if str(ROOT.parent) not in sys.path:sys.path.insert(0,str(ROOT.parent))
        from w_member import WSection
        spec=WSection(**json.loads((ROOT.parent/p['generic_section_config']).read_text()))
        if section != spec.name:raise ValueError('Generic adapter section identity mismatch')
        audit=spec.audit(ns['FIBER_MESH_ORDER'])
        if not audit['geometry_gate']:raise ValueError('Generic adapter A/I failed')
        frozen_points=ns['_fiber_section_points']
        def generic_points(name,mesh_order=None):
            if name==spec.name:return spec.fibers(mesh_order or ns['FIBER_MESH_ORDER']).tolist()
            return frozen_points(name,mesh_order)
        ns['_fiber_section_points']=generic_points
        ns.setdefault('_v11_geometry_audits',{})[section]=audit

    def make(tag,sect):
        original_material=ops.uniaxialMaterial
        def intercepted(kind,mt,*args):
            if kind=='HystereticSM':return material(ops.ops,mt,p,lp)
            return original_material(kind,mt,*args)
        ops.uniaxialMaterial=intercepted
        try:
            sec,meta=old(tag,sect)
            if p.get('generic_section_config') or p.get('generic_sections_config'):
                meta['generic_geometry_audit']=ns['_v11_geometry_audits'][sect]
            if 'Mc' not in p and not p.get('control_law'):
                env,end=envelope(p,lp);meta.update(effective_envelope=env,energy_G_N_per_mm=p['G_N_per_mm'],regularization_weight_mm=lp,domain_end=end)
                if p.get('material_api')=='Hysteretic':meta['native_negative_envelope']=[env[0],env[2],env[3]];meta['native_api']='Hysteretic'
            return sec,meta
        finally:del ops.uniaxialMaterial
    ns['_hybrid_ss_section']=make
    try:
        if 'Mc' not in p:return build_ss(ns,original,mode,lp,ele,i,j,section,release)
        ops.v09_inside_ss=True;nodes=[];springs=[]
        pts=ns['_fiber_section_points'](section);I=sum(y*y*a for y,a in pts);L=ns['get_frame_length'](i,j)
        K=p['Kfactor']*6*ns['E0']*I/L
        for end,n in enumerate([i,j]):
            inner=110000000+ele*10+end;mt=120000000+ele*10+end;st=130000000+ele*10+end
            ops.node(inner,*ops.nodeCoord(n));ns.setdefault('_v10_joint_pairs',[]).append((n,inner))
            theta=p['Mc']/K;r=p['residual_ratio'];opening=p['opening']
            env=[.5*p['Mc'],.5*theta,p['Mc'],theta,r*p['Mc'],theta+opening]
            ops.uniaxialMaterial('Hysteretic',mt,*env,*[-v for v in env],1.,1.,0.,0.)
            ops.element('zeroLength',st,n,inner,'-mat',mt,'-dir',3)
            nodes.append(inner);springs.append(dict(tag=st,external=n,internal=inner,K=K,Mc=p['Mc'],theta_cap=theta,opening=opening,residual_ratio=r))
        result=build_ss(ns,original,mode,lp,ele,*nodes,section,release)
        ns['ss_fiber_records'][-1]['connection_springs']=springs
        return result
    finally:ns['_hybrid_ss_section']=old;ops.v09_inside_ss=False

_capture=Monitor.capture
def capture(self,ns,step,roof,shear,additional_reasons=None):
    ops=ns['ops'];reasons=list(additional_reasons or []);jrows=[]
    if not hasattr(self,'p2_old'):self.p2_old={};self.p2_work={}
    # Summed actual nodal virtual work, with UDL fixed-end action retained in
    # element resisting forces. This is NOT a complete thermodynamic balance.
    element_power=0.;nodal_power=0.;bad=[];now={}
    for n in ops.getNodeTags():now[n]=np.asarray(ops.nodeDisp(n),float)
    lf=float(ops.getLoadFactor(30))
    gload={n:np.zeros(3) for n in now}
    for pat,kind,args,kw in ops.v09_load_records:
        if kind=='load':gload[int(args[0])]+=np.asarray(args[1:4],float)*(lf if pat==30 else 1.)
    eforces={}
    for e in ops.getEleTags():
        nodes=ops.eleNodes(e);force=np.asarray(ops.eleResponse(e,'force'),float)
        if len(nodes)!=2 or force.size!=6:bad.append(int(e));continue
        eforces[int(e)]=(tuple(nodes),force)
    prev=self.p2_old.get('system')
    if prev is not None:
        u0,f0,l0=prev
        for e,(nodes,f) in eforces.items():
            if e not in f0:continue
            du=np.concatenate([now[n]-u0[n] for n in nodes]);element_power+=float(np.dot(.5*(f+f0[e][1]),du))
        nodal_power=sum(float(np.dot(.5*(gload[n]+l0[n]),now[n]-u0[n])) for n in now)
    self.p2_old['system']=(now,eforces,gload)
    # Exact series compliance work split: total v = member v - joint rotation.
    section_increment=0.;basic_increment=0.;udl_increment=0.;joint_increment=0.;series_increment=0.
    for rec in ns['ss_fiber_records']:
        tag=int(rec['etabs_tag']);q=np.array(ops.eleResponse(tag,'basicForce'));v=np.array(ops.eleResponse(tag,'basicDeformation'))
        x=ops.eleResponse(tag,'integrationPoints');w=ops.eleResponse(tag,'integrationWeights');L=float(sum(w));wy,wx=self.loads.get(tag,[0.,0.]) if self.initialized else (0.,0.)
        prevmember=self.p2_old.get(('member',tag));jointtheta=np.zeros(2);jointmom=np.zeros(2)
        for end,s in enumerate(rec.get('connection_springs',[])):
            theta=ops.nodeDisp(s['internal'],3)-ops.nodeDisp(s['external'],3);M=float(ops.eleResponse(s['tag'],'force')[5]);jointtheta[end]=theta;jointmom[end]=M
            ratio=abs(M+q[end+1])/(self.c['moment_atol_Nmm']+self.c['force_rtol']*max(abs(M),abs(q[end+1])))
            if ratio>1:reasons.append('SERIES_JOINT_FORCE')
            if abs(theta)>s['theta_cap']+s['opening']:reasons.append('JOINT_DOMAIN_EXCEEDED')
            jrows.append(dict(step=step,roof_mm=roof,member=tag,end=end,theta_rad=theta,M_Nmm=M,elastic_theta_rad=M/s['K'],opening_rotation_rad=theta-M/s['K'],force_ratio=ratio,triggered=abs(theta)>=s['theta_cap']))
        if prevmember is not None:
            oq,ov,oj,om=prevmember;qm=.5*(q+oq);dv=v-ov;dj=jointtheta-oj
            basic_increment+=float(np.dot(qm,dv));joint_increment+=float(np.dot(.5*(jointmom+om),dj))
            series_increment+=float(np.dot(qm,dv-np.r_[0.,dj]))
        self.p2_old[('member',tag)]=(q,v,jointtheta,jointmom)
        for ip,(xx,ww) in enumerate(zip(x,w),1):
            sf=np.array(ops.eleResponse(tag,'section',ip,'force'));sd=np.array(ops.eleResponse(tag,'section',ip,'deformation'));old=self.p2_old.get(('section',tag,ip))
            if old is not None:
                os,od=old;dd=sd-od;section_increment+=ww*float(np.dot(.5*(sf+os),dd))
                sp=np.array([wx*(L-xx),wy*.5*xx*(xx-L),wy*(xx-.5*L)]);udl_increment+=ww*float(np.dot(sp,dd))
            self.p2_old[('section',tag,ip)]=(sf,sd)
    split=section_increment-udl_increment+joint_increment
    er=abs(split-series_increment)/max(1.,abs(split),abs(series_increment))
    vr=abs(element_power-nodal_power)/max(1.,abs(element_power),abs(nodal_power))
    energy=dict(step=step,roof_mm=roof,SS_section_work_increment_Nmm=section_increment,SS_basic_work_increment_Nmm=basic_increment,UDL_deformation_work_increment_Nmm=udl_increment,joint_work_increment_Nmm=joint_increment,series_total_work_increment_Nmm=series_increment,series_energy_relative_error=er,global_resisting_work_increment_Nmm=element_power,external_nodal_work_increment_Nmm=nodal_power,global_virtual_work_relative_error=vr,unsupported_elements=';'.join(map(str,bad)),thermodynamic_closure_claimed=False)
    append(self.out/'Energy_Audit.csv',[energy]);append(self.out/'Connection_States.csv',jrows)
    # Use work-scaled tolerance plus an absolute roundoff allowance.
    if prev is not None and abs(split-series_increment)>10.+1e-4*max(abs(split),abs(series_increment)):reasons.append('SS_ENERGY_SPLIT')
    if prev is not None and abs(element_power-nodal_power)>10.+1e-4*max(abs(element_power),abs(nodal_power)):reasons.append('GLOBAL_VIRTUAL_WORK')
    result=_capture(self,ns,step,roof,shear,reasons)
    p=self.settings['scenario']
    # Screening can stop after a confirmed 30% descending segment. Full
    # reference-domain coverage is still required by the calibration classifier.
    if p.get('screen_stop',False) and self.global_peak>1000 and shear<.67*self.global_peak:
        raise ScreeningStop('SCREEN_POSTPEAK_SEGMENT_REACHED')
    return result
Monitor.capture=capture
