"""Chronological accepted-state continuation with audited domain checkpoints.
No material, stiffness, geometry or screening threshold is modified here.
"""
import copy,json
import numpy as np
from v09_core import ScreeningStop,append
from chord_monitor import capture

def native_state(ops,ns):
    x={('time',):np.array([ops.getTime()])}
    for n in ops.getNodeTags():x[('u',int(n))]=np.asarray(ops.nodeDisp(n))
    for e in ops.getEleTags():x[('f',int(e))]=np.asarray(ops.eleResponse(e,'force'))
    for rec in ns['ss_fiber_records']:
        e=int(rec['etabs_tag'])
        for ip in range(1,7):
            for response in ('force','deformation','fiberData'):x[(response,e,ip)]=np.asarray(ops.eleResponse(e,'section',ip,response))
    return x

def compare(a,b):
    if set(a)!=set(b):return False,float('inf')
    maximum=0.
    for k,v in a.items():
        z=b[k]
        if v.shape!=z.shape or not np.isfinite(z).all():return False,float('inf')
        absolute=1e-8 if k[0] in ('time','u','deformation') else 1e-5
        r=float(np.max(abs(v-z)/(absolute+1e-9*np.maximum(abs(v),abs(z))))) if len(v) else 0.
        maximum=max(maximum,r)
    return maximum<=1,maximum

def drive(ns,monitor,c,settings):
    ops=ns['ops'];context=ns['_automation'];p=settings['scenario'];maxsteps=p.get('maxsteps',5000)
    capture(monitor,ns,0,context.control_displacement(),context.base_shear_kN())
    floor=p.get('minimum_step',.0078125);near=p.get('postpeak_step',.125);start=p.get('refine_roof',390.)
    peak=max(0.,context.base_shear_kN());peakstep=0;cross=None;confirmed=0;step=0;trial=0;db=False
    def rebuild(du,alg):
        ops.wipeAnalysis();ops.constraints('Plain');ops.numberer('RCM');ops.system('BandGeneral')
        ops.test('NormUnbalance',p.get('unbalance_tolerance',1e-3),p.get('iterations',100))
        if alg=='NewtonLineSearch':ops.algorithm(alg,'-type','Bisection','-tol',.8,'-maxIter',10)
        else:ops.algorithm(alg)
        ops.integrator('DisplacementControl',context.control['control_node'],1,float(du)*context.direction);ops.analysis('Static')
    while step<maxsteps:
        roof=context.control_displacement();du=near if roof>=start else settings['step']
        if roof>=settings['target']:raise ScreeningStop('SAFETY_DISPLACEMENT_BOUND_NOT_SUCCESS')
        if roof>=p.get('checkpoint_roof',420.) and not db:
            ops.database('File',str(monitor.out/'Accepted_Domain_DB'));db=True
        before=native_state(ops,ns) if db else None
        old_monitor=copy.deepcopy(monitor.__dict__) if db else None
        if db:ops.save(1)
        success=False
        while du>=floor-1e-12 and not success:
            for alg in p.get('algorithms',['Newton','NewtonLineSearch','KrylovNewton']):
                rebuild(du,alg);code=ops.analyze(1)
                if code:continue
                try:
                    trial+=1
                    capture(monitor,ns,trial,context.control_displacement(),context.base_shear_kN())
                    success=True;break
                except ScreeningStop as exc:
                    append(monitor.out/'Mechanical_Recovery.csv',[dict(step=step+1,roof_rejected=context.control_displacement(),du=du,algorithm=alg,reasons=str(exc))])
                    if not db:raise
                    ops.wipeAnalysis();ops.restore(1)
                    okay,error=compare(before,native_state(ops,ns))
                    append(monitor.out/'Checkpoint_Restore_Audit.csv',[dict(step=step,restored=okay,max_scaled_error=error)])
                    if not okay:raise ScreeningStop('DOMAIN_CHECKPOINT_RESTORE_FAILED')
                    monitor.__dict__.clear();monitor.__dict__.update(copy.deepcopy(old_monitor))
                    # Rejected histories are retained, with a unique trial counter
                    # supplied by the recorder; only accepted rows enter capacity.
            if not success:du*=.5
        if not success:raise ScreeningStop('POSTPEAK_MIN_STEP_REACHED_WITHOUT_VALID_STATE')
        step+=1;shear=context.base_shear_kN()
        if shear>peak:peak=shear;peakstep=step;cross=None;confirmed=0
        if step>peakstep and shear<=.8*peak:
            if cross is None:cross=dict(step=step,roof_mm=context.control_displacement(),V_kN=shear)
            confirmed+=1
        elif cross is not None:confirmed=0
        check=dict(Vmax_kN=peak,Vtarget_descending_kN=.8*peak,peak_step=peakstep,current_step=step,current_roof_mm=context.control_displacement(),current_V_kN=shear,
            first_accepted_crossing=cross,accepted_steps_at_or_below_threshold=confirmed,success=cross is not None and confirmed>=4,
            chronological_order_preserved=True,physical_validation=False,target_displacement_mm=None,target_1p5_status='NOT_CALCULATED; hazard/performance inputs not specified')
        (monitor.out/'POSTPEAK_80PCT_CHECK.json').write_text(json.dumps(check,indent=2))
        if check['success']:
            (monitor.out/'Driver_End.json').write_text(json.dumps(dict(reason='POSTPEAK_80PCT_CONFIRMED',**check),indent=2));return
    raise ScreeningStop('POSTPEAK_MAXIMUM_STEPS_REACHED')
