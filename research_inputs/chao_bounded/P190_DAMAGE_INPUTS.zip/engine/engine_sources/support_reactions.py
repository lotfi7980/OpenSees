"""Recover support reactions including MP slaves retained by fixed base DOFs."""
def support_shear(context):
    ops=context.ops;ops.reactions();supports={int(n) for n in context.ns['Node_Restriant_label']}
    nodes=set(supports)
    for (slave,dof),master in context.ns['dof_master'].items():
        if dof==1 and int(master) in supports:nodes.add(int(slave))
    return -sum(float(ops.nodeReaction(n,1)) for n in nodes)/1000
