"""Independent experiment adapter for the frozen, actually executed SS engine.
N-mm-MPa. No imports from or writes to the original building codes.
"""
from pathlib import Path
import types,sys,json,csv,copy,hashlib,math
import numpy as np
import openseespy.opensees as raw
ROOT=Path(__file__).resolve().parent

def dump(path,data):Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=False,default=lambda a:a.item() if isinstance(a,np.generic) else a.tolist()),encoding='utf-8')
def table(path,rows):
    rows=list(rows) or [dict(status='NO_DATA')]
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader()
        for r in rows:w.writerow({k:json.dumps(v) if isinstance(v,(dict,list,tuple)) else v for k,v in r.items()})
def read(path):
    with Path(path).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def latest(name):
    p=Path((ROOT/name).read_text(encoding='utf-8').strip());return p if p.is_absolute() else ROOT/p

MODULES={}
def engines():
    if MODULES:return MODULES
    manifest=json.loads((ROOT/'ENGINE_SOURCE_MANIFEST.json').read_text())
    for name in ('v09_core','scenarios','postpeak_solver'):
        path=ROOT/'engine_sources'/(name+'.py');assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest[name]['sha256']
        text=path.read_text()
        for dep in ('v09_core','chord_monitor'):text=text.replace('from '+dep+' import','from _chao_'+dep+' import')
        if name=='postpeak_solver':
            bridge=types.ModuleType('_chao_chord_monitor');bridge.capture=lambda mon,*a:mon.capture(*a);sys.modules[bridge.__name__]=bridge
        mod=types.ModuleType('_chao_'+name);mod.__file__=str(path);sys.modules[mod.__name__]=mod
        exec(compile(text,str(path),'exec'),mod.__dict__);MODULES[name]=mod
    return MODULES

PARAMS=json.loads((ROOT/'inputs/LOCKED_N_OPT01.json').read_text())
CONTROLS=json.loads((ROOT/'inputs/ENGINE_CONTROLS.json').read_text())
if PARAMS!=json.loads((ROOT/'ENGINE_SOURCE_MANIFEST.json').read_text())['locked_N_OPT01']:
    raise RuntimeError('Locked N_OPT01 parameters differ from the executed-source manifest; calibration changes are prohibited in this validation.')

def mapped_envelope(fy,E,lp):
    """Exact source formula generalized only for measured Fy and assumed E.
    cap, peak_ratio, residual_ratio, G, domain, and .015 kink are unchanged.
    444.36 MPa maps by Fy/396.75, not by curve fitting. G stays absolute.
    """
    s=engines()['scenarios']
    import ast
    text=(ROOT/'engine_sources/scenarios.py').read_text();node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='envelope')
    source='\n'.join(text.splitlines()[node.lineno-1:node.end_lineno])
    source=source.replace('fy=396.75;E=200000.','fy=_FY;E=_E').replace('444.36','(444.36*fy/396.75)')
    g=dict(_FY=float(fy),_E=float(E));exec(source,g)
    return g['envelope'](PARAMS,lp)

def material(ops,tag,fy,E,lp):
    s=engines()['scenarios'];old=s.envelope
    try:
        s.envelope=lambda p,h:mapped_envelope(fy,E,h)
        s.material(ops,tag,copy.deepcopy(PARAMS),lp) # original HystereticSM API and defaults
    finally:s.envelope=old

def material_transfer_checks():
    s=engines()['scenarios'];tests=[]
    class Recorder:
        def uniaxialMaterial(self,*a):self.args=a
    a=Recorder();b=Recorder();s.material(a,1,copy.deepcopy(PARAMS),100.);material(b,1,396.75,200000.,100.)
    assert a.args==b.args
    for fy in (352.,396.75,405.,470.):
        for h in (90.,100.,110.):
            env,end=mapped_envelope(fy,200000.,h);sc,ec=env[2];sr,er=env[3]
            energy=.5*(sc-sr)*h*((er-sr/200000.)-(ec-sc/200000.))
            assert abs(energy/PARAMS['G_N_per_mm']-1)<1e-12
            assert abs(env[0][0]/fy-1)<1e-12 and abs(env[0][1]-fy/200000.)<1e-12
            tests.append(dict(Fy_MPa=fy,lp_mm=h,G_reintegrated_N_per_mm=energy,cap_strain=ec,residual_strain=end,status='PASS'))
    return dict(reference_material_arguments_identical=True,formula='sigma_y=Fy; sigma_k=444.36*Fy/396.75; sigma_c=Fy*peak_ratio; sigma_r=Fy*residual_ratio; eps_c=cap; eps_r=eps_c+2G/(lp*(sigma_c-sigma_r))+(sigma_r-sigma_c)/E',G_mapping='FIXED_ABSOLUTE_G; portability assumption, NOT a measured channel fracture energy',tests=tests)

def channel_fibers(mesh=64,d=203.2,b=64.3,tf=9.91,tw=12.37,gap=25.,fy_flange=352.,fy_web=352.):
    assert mesh in (64,128)
    q,w=np.polynomial.legendre.leggauss(mesh//8);pts=[]
    # Cross section: back-to-back vertical webs against the opposite faces of
    # the center gusset; flanges extend outward. y is the depth coordinate;
    # z records the actual channel separation. Strong-axis bending uses y.
    for sign in (-1,1):
        for lo,hi,width,fy,zone,zlocal in [(-d/2,-d/2+tf,b,fy_flange,'FLANGE',b/2),(d/2-tf,d/2,b,fy_flange,'FLANGE',b/2),(-d/2+tf,0.,tw,fy_web,'WEB',tw/2),(0.,d/2-tf,tw,fy_web,'WEB',tw/2)]:
            for x,wt in zip(q,w):pts.append(dict(y_mm=(lo+hi)/2+x*(hi-lo)/2,z_mm=sign*(gap/2+zlocal),area_mm2=width*wt*(hi-lo)/2,Fy_MPa=fy,zone=zone,channel=sign))
    return pts

def section_properties(points):
    a=np.array([p['area_mm2'] for p in points]);y=np.array([p['y_mm'] for p in points]);z=np.array([p['z_mm'] for p in points]);yc=float(a@y/sum(a));zc=float(a@z/sum(a))
    return dict(A_mm2=float(sum(a)),I_strong_mm4=float(sum(a*(y-yc)**2)),Z_strong_mm3=float(sum(a*abs(y-yc))),centroid_y_mm=yc,centroid_z_mm=zc)

class Recorder:
    def __init__(self):
        self.v09_inside_ss=False;self.v09_outside_commands=[];self.v09_load_records=[];self.v09_algorithm=None;self.v09_integrator=None;self.pattern_id=None
    def __getattr__(self,name):
        fn=getattr(raw,name)
        def call(*a,**k):
            if name=='pattern':self.pattern_id=a[1]
            if name in ('load','eleLoad'):self.v09_load_records.append((self.pattern_id,name,list(a),k))
            if name=='algorithm':self.v09_algorithm=a
            if name=='integrator':self.v09_integrator=a
            if name in ('node','fix','equalDOF','rigidLink','element','section','uniaxialMaterial','geomTransf','mass') and not self.v09_inside_ss:self.v09_outside_commands.append((name,a,k))
            return fn(*a,**k)
        return call

class Context:
    def __init__(self,ops,tip,levels):self.ops=ops;self.tip=tip;self.levels=levels;self.nodal_loads={tip:1.};self.direction=1;self.D_factor=0.;self.L_factor=0.;self.Ki=0.;self.control={'control_node':tip}
    def control_displacement(self):return self.ops.nodeDisp(self.tip,1)
    def base_shear_kN(self):self.ops.reactions();return -sum(self.ops.nodeReaction(n,1) for n in self.ops.getNodeTags())/1000.

def add_ss(ns,tag,i,j,points,lp,E=200000.,elastic=False):
    core=engines()['v09_core'];ops=ns['ops'];props=section_properties(points);Av=2*12.37*(203.2-2*9.91)
    def make(ele,name):
        sec=80_000_000+ele*10;shear=70_000_000+ele*100+90;tags={}
        for fy in sorted(set(p['Fy_MPa'] for p in points)):
            mat=70_000_000+ele*100+len(tags)+1
            if elastic:ops.uniaxialMaterial('Elastic',mat,E)
            else:material(ops,mat,fy,E,lp)
            tags[fy]=mat
        ops.section('Fiber',sec)
        for p in points:ops.fiber(p['y_mm'],p['z_mm'],p['area_mm2'],tags[p['Fy_MPa']])
        ops.uniaxialMaterial('Elastic',shear,E/2.6*Av);ops.section('Aggregator',sec+1,shear,'Vy','-section',sec)
        return sec+1,dict(etabs_tag=ele,section='DOUBLE_CHANNEL_EXPLICIT',fiber_count=len(points),material_Fy=sorted(tags),A_Fiber=props['A_mm2'],I_Fiber=props['I_strong_mm4'])
    ns['_hybrid_ss_section']=make;ns['_fiber_section_points']=lambda name:[(p['y_mm'],p['area_mm2']) for p in points]
    ns['get_section_properties']=lambda name:(props['A_mm2'],Av,props['I_strong_mm4'])
    ns['get_frame_length']=lambda i,j:float(np.linalg.norm(np.array(ops.nodeCoord(j))-ops.nodeCoord(i)))
    def check(t,label):
        if t in ops.getEleTags():raise ValueError('Duplicate element tag')
    ns['check_new_element_tag']=check
    ns['_p2_local']=PARAMS
    return core.build_ss(ns,None,'HingeRadau',lp,tag,i,j,'DOUBLE_CHANNEL_EXPLICIT',0)

def cantilever(mesh=64,lp=100.,E=200000.,root_ratio=None,elastic=False):
    ops=Recorder();ops.wipe();ops.model('basic','-ndm',2,'-ndf',3);L=1372.
    ops.node(1,0.,0.);ops.fix(1,1,1,1);ops.node(2,0.,L);ops.geomTransf('PDelta',1)
    pts=channel_fibers(mesh);props=section_properties(pts);base=1
    if root_ratio is not None:
        ops.node(3,0.,0.);ops.equalDOF(1,3,1,2);K=root_ratio*3*E*props['I_strong_mm4']/L
        ops.uniaxialMaterial('Elastic',9001,K);ops.element('zeroLength',9002,1,3,'-mat',9001,'-dir',3);base=3
    ns=dict(ops=ops,E0=E,P_delta=1,ss_fiber_records=[],SS_MATERIAL_CASE='N_OPT01_TRANSFER',T1_gravity=0.,T1_initial=0.,hinge_records=[])
    add_ss(ns,101,base,2,pts,lp,E,elastic)
    ctx=Context(ops,2,[dict(elevation=L,mass_nodes=[2])]);ns['_automation']=ctx
    ops.timeSeries('Linear',30);ops.pattern('Plain',30,30);ops.load(2,1.,0.,0.)
    return ns,pts

def analysis(ops,du,algorithm='Newton',handler='Plain'):
    ops.wipeAnalysis();ops.constraints(handler);ops.numberer('RCM');ops.system('BandGeneral');ops.test('NormDispIncr',1e-10,100)
    if algorithm=='NewtonLineSearch':ops.algorithm(algorithm,'-type','Bisection','-tol',.8,'-maxIter',10)
    else:ops.algorithm(algorithm)
    ops.integrator('DisplacementControl',2,1,float(du));ops.analysis('Static')

def run_path(ns,out,targets,step_mm=.5,full_fibers=True):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);ops=ns['ops'];ctx=ns['_automation'];core=engines()['v09_core'];native=engines()['postpeak_solver'];lp=ns['ss_fiber_records'][0]['lp_mm']
    controls=copy.deepcopy(CONTROLS);controls['record_fiber_tags']=[r['etabs_tag'] for r in ns['ss_fiber_records']] if full_fibers else []
    settings=dict(scenario=copy.deepcopy(PARAMS),cap_strain=PARAMS['cap']);monitor=core.Monitor(out,controls,settings)
    ops.wipeAnalysis();ops.constraints(ns.get('constraint_handler','Plain'));ops.numberer('RCM');ops.system('BandGeneral');ops.test('NormDispIncr',1e-10,100);ops.algorithm('Newton');ops.integrator('LoadControl',0.);ops.analysis('Static');assert ops.analyze(1)==0
    ops.database('File',str(out/'CHECKPOINT'));monitor.capture(ns,0,0.,0.)
    rows=[];states=[];attempts=[];trial=0;failure=None
    def capture_row(excursion):
        u=ctx.control_displacement();force=ops.getLoadFactor(30);ops.reactions();Rz=sum(ops.nodeReaction(n,3) for n in ops.getNodeTags());maxstrain=0.;soft=0.
        for rec in ns['ss_fiber_records']:
            tag=rec['etabs_tag']
            for ip,w in enumerate(ops.eleResponse(tag,'integrationWeights'),1):
                f=np.array(ops.eleResponse(tag,'section',ip,'fiberData'))
                if not len(f):continue
                f=f.reshape(-1,5);mx=float(max(abs(f[:,4])));maxstrain=max(maxstrain,mx);soft+=w*(mx>=PARAMS['cap'])
                states.append(dict(step=trial,excursion=excursion,member=tag,ip=ip,max_abs_strain=mx,curvature_per_mm=ops.eleResponse(tag,'section',ip,'deformation')[1],softening=mx>=PARAMS['cap'],FY_dependent_yield_events='Reference monitor event threshold is 396.75/200000; use actual stress/strain and Fy metadata, not that reference event',P_M_V=ops.eleResponse(tag,'section',ip,'force')))
        length=float(ops.nodeCoord(ctx.tip)[1]);row=dict(step=trial,excursion=excursion,u_mm=u,theta_rad=u/length,F_kN=force/1000.,M_nominal_kNm=force*length/1e6,M_reaction_kNm=Rz/1e6,nominal_moment_equilibrium_error_Nmm=Rz-force*length,max_abs_fiber_strain=maxstrain,softening_extent_mm=soft,accepted=True,physical_validation=False)
        if '_measure' in ns:row.update(ns['_measure']())
        rows.append(row)
    capture_row(0)
    for excursion,target in enumerate(targets,1):
        while abs(target-ctx.control_displacement())>1e-7:
            before=native.native_state(ops,ns);old=copy.deepcopy(monitor.__dict__);ops.save(1);du=np.sign(target-ctx.control_displacement())*min(step_mm,abs(target-ctx.control_displacement()));success=False
            trial_floor=min(.000244140625,abs(target-ctx.control_displacement()))
            while abs(du)>=trial_floor-1e-12 and not success:
                for alg in ('Newton','NewtonLineSearch','KrylovNewton'):
                    ops.wipeAnalysis();ops.restore(1);monitor.__dict__.clear();monitor.__dict__.update(copy.deepcopy(old))
                    ok,err=native.compare(before,native.native_state(ops,ns))
                    if not ok:raise RuntimeError('Native checkpoint restore comparison failed')
                    analysis(ops,du,alg,ns.get('constraint_handler','Plain'));code=ops.analyze(1);trial+=1;reason=''
                    if code==0:
                        try:monitor.capture(ns,trial,ctx.control_displacement(),ctx.base_shear_kN());success=True
                        except core.ScreeningStop as exc:reason=str(exc)
                    attempts.append(dict(trial=trial,excursion=excursion,target_mm=target,increment_mm=du,algorithm=alg,native_code=code,accepted=success,reason=reason,restore_pass=True,restore_scaled_error=err))
                    if success:break
                if not success:du*=.5
            if not success:
                ops.wipeAnalysis();ops.restore(1);monitor.__dict__.clear();monitor.__dict__.update(old);failure='MIN_STEP_OR_MECHANICAL_SCREEN';break
            capture_row(excursion)
        if failure:break
    table(out/'RESPONSE.csv',rows);table(out/'FIBER_STATE_HISTORY.csv',states);table(out/'CONTINUATION_ATTEMPTS.csv',attempts)
    result=dict(status='COMPLETED' if not failure else 'FAILED',failure=failure,accepted_steps=len(rows),trials=len(attempts),completed_excursions=max(r['excursion'] for r in rows),requested_excursions=len(targets),last_theta_rad=rows[-1]['theta_rad'],max_abs_fiber_strain=max(r['max_abs_fiber_strain'] for r in rows),all_restore_checks_passed=all(a['restore_pass'] for a in attempts),material_parameters=PARAMS,lp_mm=lp,native_solver='NormDispIncr 1e-10 + original independent screens',physical_validation=False)
    dump(out/'RUN_SUMMARY.json',result);return rows,result
